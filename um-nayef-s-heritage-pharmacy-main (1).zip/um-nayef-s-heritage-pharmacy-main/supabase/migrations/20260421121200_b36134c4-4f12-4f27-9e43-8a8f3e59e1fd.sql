
-- enum للأدوار
CREATE TYPE public.app_role AS ENUM ('admin', 'customer');

-- جدول المستخدمين (بدون auth حقيقي - بسيط بالاسم والهاتف)
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- جدول الأدوار (منفصل لمنع الترقية الخبيثة)
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone TEXT NOT NULL,
  role app_role NOT NULL,
  UNIQUE(phone, role)
);

-- إضافة أم نايف كمسؤول
INSERT INTO public.user_roles (phone, role) VALUES ('0569529224', 'admin');

-- دالة فحص الدور
CREATE OR REPLACE FUNCTION public.has_role(_phone TEXT, _role app_role)
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE phone = _phone AND role = _role)
$$;

-- المنتجات
CREATE TABLE public.products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC(10,2) NOT NULL,
  image_url TEXT,
  stock INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- الطلبات
CREATE TABLE public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_code TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  customer_address TEXT NOT NULL,
  total NUMERIC(10,2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'قيد المراجعة',
  receipt_url TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- عناصر الطلب
CREATE TABLE public.order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
  product_name TEXT NOT NULL,
  price NUMERIC(10,2) NOT NULL,
  quantity INTEGER NOT NULL
);

-- إعدادات الدفع
CREATE TABLE public.payment_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bank_name TEXT NOT NULL,
  account_holder TEXT NOT NULL,
  iban TEXT NOT NULL,
  account_number TEXT,
  instructions TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO public.payment_settings (bank_name, account_holder, iban, account_number, instructions)
VALUES ('الراجحي', 'أم نايف', 'SA0000000000000000000000', '000000000000', 'حول المبلغ ثم ارفع صورة الإيصال');

-- تفعيل RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_settings ENABLE ROW LEVEL SECURITY;

-- السياسات: قراءة مفتوحة للمنتجات والدفع
CREATE POLICY "anyone_view_products" ON public.products FOR SELECT USING (true);
CREATE POLICY "anyone_manage_products" ON public.products FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "anyone_view_payment" ON public.payment_settings FOR SELECT USING (true);
CREATE POLICY "anyone_manage_payment" ON public.payment_settings FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "anyone_view_profiles" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "anyone_insert_profiles" ON public.profiles FOR INSERT WITH CHECK (true);
CREATE POLICY "anyone_update_profiles" ON public.profiles FOR UPDATE USING (true);

CREATE POLICY "anyone_view_roles" ON public.user_roles FOR SELECT USING (true);

CREATE POLICY "anyone_view_orders" ON public.orders FOR SELECT USING (true);
CREATE POLICY "anyone_insert_orders" ON public.orders FOR INSERT WITH CHECK (true);
CREATE POLICY "anyone_update_orders" ON public.orders FOR UPDATE USING (true);

CREATE POLICY "anyone_view_order_items" ON public.order_items FOR SELECT USING (true);
CREATE POLICY "anyone_insert_order_items" ON public.order_items FOR INSERT WITH CHECK (true);

-- buckets للصور
INSERT INTO storage.buckets (id, name, public) VALUES ('products', 'products', true), ('receipts', 'receipts', true);

CREATE POLICY "public_read_products_bucket" ON storage.objects FOR SELECT USING (bucket_id = 'products');
CREATE POLICY "public_write_products_bucket" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'products');
CREATE POLICY "public_update_products_bucket" ON storage.objects FOR UPDATE USING (bucket_id = 'products');
CREATE POLICY "public_delete_products_bucket" ON storage.objects FOR DELETE USING (bucket_id = 'products');

CREATE POLICY "public_read_receipts_bucket" ON storage.objects FOR SELECT USING (bucket_id = 'receipts');
CREATE POLICY "public_write_receipts_bucket" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'receipts');
