import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/Header";
import { SaduDivider } from "@/components/SaduDivider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

interface OrderRow {
  id: string;
  order_code: string;
  customer_name: string;
  customer_phone: string;
  customer_address: string;
  total: number;
  status: string;
  created_at: string;
  notes: string | null;
}

interface OrderItem {
  product_name: string;
  price: number;
  quantity: number;
}

const TrackOrder = () => {
  const [phone, setPhone] = useState("");
  const [orders, setOrders] = useState<(OrderRow & { items: OrderItem[] })[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const search = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone.trim()) return;
    setLoading(true);
    setSearched(true);
    const { data: ords } = await supabase.from("orders").select("*")
      .eq("customer_phone", phone.trim()).order("created_at", { ascending: false });
    
    if (ords && ords.length) {
      const ids = ords.map(o => o.id);
      const { data: its } = await supabase.from("order_items").select("*").in("order_id", ids);
      const enriched = ords.map(o => ({
        ...o,
        items: (its || []).filter(i => i.order_id === o.id) as OrderItem[],
      }));
      setOrders(enriched as any);
    } else {
      setOrders([]);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen">
      <Header />
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <h2 className="heritage-title text-4xl text-center mb-2">تتبع الطلب</h2>
        <p className="text-center text-muted-foreground">أدخل رقم جوالك لعرض طلباتك</p>
        <SaduDivider />

        <form onSubmit={search} className="card-3d p-6 mb-6 flex gap-2">
          <Input value={phone} onChange={e => setPhone(e.target.value)} placeholder="05XXXXXXXX" dir="ltr" maxLength={10} />
          <Button type="submit" className="btn-heritage" disabled={loading}>{loading ? "..." : "بحث"}</Button>
        </form>

        {searched && !loading && orders.length === 0 && (
          <div className="card-3d sadu-frame p-6 text-center text-primary">لا توجد طلبات بهذا الرقم</div>
        )}

        <div className="space-y-4">
          {orders.map(o => (
            <div key={o.id} className="card-3d sadu-frame p-5">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="text-xs text-muted-foreground">كود الطلب</p>
                  <p className="font-black text-primary text-xl tracking-wider" dir="ltr">{o.order_code}</p>
                </div>
                <span className="px-3 py-1 rounded-full text-xs font-bold" style={{
                  background: "var(--gradient-gold)", color: "hsl(var(--primary))"
                }}>{o.status}</span>
              </div>
              <div className="text-sm space-y-1 my-3">
                <p><span className="text-muted-foreground">الاسم:</span> <strong>{o.customer_name}</strong></p>
                <p><span className="text-muted-foreground">العنوان:</span> {o.customer_address}</p>
                <p><span className="text-muted-foreground">التاريخ:</span> {new Date(o.created_at).toLocaleString("ar-SA")}</p>
              </div>
              <div className="border-t border-dashed pt-2">
                <p className="text-xs font-bold text-primary mb-1">المنتجات:</p>
                {o.items.map((it, idx) => (
                  <div key={idx} className="text-sm flex justify-between">
                    <span>{it.product_name} × {it.quantity}</span>
                    <span>{(it.price * it.quantity).toFixed(2)} ر.س</span>
                  </div>
                ))}
              </div>
              <div className="border-t-2 border-primary mt-2 pt-2 flex justify-between font-black text-primary">
                <span>الإجمالي:</span><span>{Number(o.total).toFixed(2)} ر.س</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TrackOrder;
