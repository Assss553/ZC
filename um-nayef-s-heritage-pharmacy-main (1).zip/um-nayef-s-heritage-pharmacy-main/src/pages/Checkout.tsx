import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/Header";
import { SaduDivider } from "@/components/SaduDivider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { CartItem, getCart, cartTotal, clearCart } from "@/lib/cart";
import { generateOrderCode, getUser } from "@/lib/auth";
import { toast } from "sonner";
import { Copy, Upload, CheckCircle2 } from "lucide-react";

interface PaymentSettings {
  bank_name: string;
  account_holder: string;
  iban: string;
  account_number: string | null;
  instructions: string | null;
}

const Checkout = () => {
  const user = getUser();
  const [items, setItems] = useState<CartItem[]>([]);
  const [payment, setPayment] = useState<PaymentSettings | null>(null);
  const [name, setName] = useState(user?.name || "");
  const [phone, setPhone] = useState(user?.phone || "");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState<{ code: string } | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    setItems(getCart());
    supabase.from("payment_settings").select("*").limit(1).maybeSingle()
      .then(({ data }) => setPayment(data));
  }, []);

  const copyIban = () => {
    if (payment?.iban) {
      navigator.clipboard.writeText(payment.iban);
      toast.success("تم نسخ رقم الآيبان");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) { toast.error("السلة فارغة"); return; }
    if (!name.trim() || !phone.trim() || !address.trim()) {
      toast.error("الرجاء تعبئة كل البيانات"); return;
    }
    if (!/^05\d{8}$/.test(phone.trim())) {
      toast.error("رقم جوال غير صحيح"); return;
    }

    setSubmitting(true);
    try {
      let receiptUrl: string | null = null;
      if (receiptFile) {
        const ext = receiptFile.name.split(".").pop();
        const path = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
        const { error: upErr } = await supabase.storage.from("receipts").upload(path, receiptFile);
        if (upErr) throw upErr;
        const { data } = supabase.storage.from("receipts").getPublicUrl(path);
        receiptUrl = data.publicUrl;
      }

      const code = generateOrderCode();
      const total = cartTotal();
      
      const { data: order, error: orderErr } = await supabase.from("orders").insert({
        order_code: code,
        customer_name: name.trim(),
        customer_phone: phone.trim(),
        customer_address: address.trim(),
        total,
        notes: notes.trim() || null,
        receipt_url: receiptUrl,
        status: "قيد المراجعة",
      }).select().single();
      if (orderErr) throw orderErr;

      const orderItems = items.map(i => ({
        order_id: order.id,
        product_id: i.product_id,
        product_name: i.name,
        price: i.price,
        quantity: i.quantity,
      }));
      await supabase.from("order_items").insert(orderItems);

      clearCart();
      setSuccess({ code });
    } catch (err: any) {
      toast.error("حدث خطأ: " + (err.message || "حاول لاحقاً"));
    } finally { setSubmitting(false); }
  };

  if (success) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="container mx-auto px-4 py-12 max-w-xl">
          <div className="card-3d sadu-frame p-8 text-center">
            <CheckCircle2 className="mx-auto h-16 w-16 text-primary mb-4" />
            <h2 className="heritage-title text-3xl mb-2">تم استلام طلبك!</h2>
            <p className="text-muted-foreground mb-4">احفظ كود الطلب لمتابعته لاحقاً</p>
            <SaduDivider />
            <div className="my-6 p-6 rounded-xl" style={{ background: "var(--gradient-gold)", boxShadow: "var(--shadow-carved)" }}>
              <p className="text-sm font-bold text-primary mb-2">كود طلبك</p>
              <p className="text-4xl font-black text-primary tracking-widest" dir="ltr">{success.code}</p>
              <Button size="sm" variant="ghost" className="mt-2" onClick={() => {
                navigator.clipboard.writeText(success.code); toast.success("تم النسخ");
              }}><Copy className="h-4 w-4 ml-1" /> نسخ</Button>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              ستتم مراجعة طلبك خلال ساعات وسيتم التواصل معك على رقم {phone}
            </p>
            <div className="flex gap-2 justify-center">
              <Button className="btn-heritage" onClick={() => navigate("/")}>الصفحة الرئيسية</Button>
              <Button className="btn-gold" onClick={() => navigate("/track")}>تتبع الطلب</Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <h2 className="heritage-title text-4xl text-center mb-2">إتمام الطلب والدفع</h2>
        <SaduDivider />

        {/* بيانات الدفع */}
        {payment && (
          <div className="card-3d sadu-frame p-6 mb-6">
            <h3 className="font-black text-primary text-xl mb-3">💳 بيانات التحويل البنكي</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">البنك:</span><span className="font-bold">{payment.bank_name}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">اسم المستفيد:</span><span className="font-bold">{payment.account_holder}</span></div>
              <div className="flex justify-between items-center gap-2">
                <span className="text-muted-foreground">الآيبان:</span>
                <div className="flex items-center gap-1">
                  <span className="font-bold font-mono text-xs" dir="ltr">{payment.iban}</span>
                  <Button type="button" size="icon" variant="ghost" className="h-7 w-7" onClick={copyIban}><Copy className="h-3 w-3" /></Button>
                </div>
              </div>
              {payment.instructions && (
                <p className="text-xs text-muted-foreground border-t pt-2 mt-2">{payment.instructions}</p>
              )}
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="card-3d p-6 space-y-4">
          <h3 className="font-black text-primary text-xl">📝 بيانات التوصيل</h3>
          <div>
            <Label className="text-primary font-bold">الاسم الكامل</Label>
            <Input value={name} onChange={e => setName(e.target.value)} maxLength={50} required />
          </div>
          <div>
            <Label className="text-primary font-bold">رقم الجوال</Label>
            <Input value={phone} onChange={e => setPhone(e.target.value)} type="tel" maxLength={10} dir="ltr" required />
          </div>
          <div>
            <Label className="text-primary font-bold">العنوان بالتفصيل (المدينة، الحي، الشارع، رقم المنزل)</Label>
            <Textarea value={address} onChange={e => setAddress(e.target.value)} rows={3} maxLength={300} required />
          </div>
          <div>
            <Label className="text-primary font-bold">ملاحظات (اختياري)</Label>
            <Textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} maxLength={200} />
          </div>
          <div>
            <Label className="text-primary font-bold flex items-center gap-1"><Upload className="h-4 w-4"/> صورة إيصال التحويل (اختياري)</Label>
            <Input type="file" accept="image/*" onChange={e => setReceiptFile(e.target.files?.[0] || null)} className="mt-1" />
          </div>

          <div className="border-t-2 border-dashed border-primary pt-4">
            <div className="flex justify-between text-xl font-black text-primary">
              <span>الإجمالي للتحويل:</span>
              <span>{cartTotal().toFixed(2)} ر.س</span>
            </div>
          </div>

          <Button type="submit" disabled={submitting || items.length === 0} className="btn-heritage w-full text-lg">
            {submitting ? "جاري الإرسال..." : "تأكيد الطلب"}
          </Button>
        </form>
      </div>
    </div>
  );
};

export default Checkout;
