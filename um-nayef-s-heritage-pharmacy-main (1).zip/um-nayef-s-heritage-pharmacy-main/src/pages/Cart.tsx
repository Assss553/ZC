import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Header } from "@/components/Header";
import { SaduDivider } from "@/components/SaduDivider";
import { Button } from "@/components/ui/button";
import { CartItem, getCart, removeFromCart, updateQty, cartTotal } from "@/lib/cart";
import { Trash2, Plus, Minus } from "lucide-react";

const Cart = () => {
  const [items, setItems] = useState<CartItem[]>([]);
  const navigate = useNavigate();

  useEffect(() => { setItems(getCart()); }, []);

  const refresh = () => setItems(getCart());

  return (
    <div className="min-h-screen">
      <Header />
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <h2 className="heritage-title text-4xl text-center mb-2">سلة المشتريات</h2>
        <SaduDivider />

        {items.length === 0 ? (
          <div className="card-3d sadu-frame p-8 text-center">
            <p className="text-lg text-primary mb-4">السلة فارغة</p>
            <Link to="/"><Button className="btn-heritage">تصفح المنتجات</Button></Link>
          </div>
        ) : (
          <>
            <div className="space-y-3">
              {items.map(item => (
                <div key={item.product_id} className="card-3d p-4 flex gap-3 items-center">
                  <div className="w-20 h-20 rounded-lg bg-muted overflow-hidden flex-shrink-0">
                    {item.image_url ? (
                      <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />
                    ) : (<div className="w-full h-full flex items-center justify-center text-3xl">🫘</div>)}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-primary">{item.name}</h3>
                    <p className="text-sm text-muted-foreground">{item.price.toFixed(2)} ر.س</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Button size="icon" variant="outline" className="h-8 w-8"
                        onClick={() => { updateQty(item.product_id, item.quantity - 1); refresh(); }}>
                        <Minus className="h-4 w-4" />
                      </Button>
                      <span className="font-bold w-8 text-center">{item.quantity}</span>
                      <Button size="icon" variant="outline" className="h-8 w-8"
                        onClick={() => { updateQty(item.product_id, item.quantity + 1); refresh(); }}>
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="text-left">
                    <div className="font-black text-primary">{(item.price * item.quantity).toFixed(2)}</div>
                    <Button size="icon" variant="ghost" className="text-destructive"
                      onClick={() => { removeFromCart(item.product_id); refresh(); }}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            <div className="card-3d sadu-frame p-6 mt-6">
              <div className="flex justify-between text-2xl font-black text-primary mb-4">
                <span>الإجمالي:</span>
                <span>{cartTotal().toFixed(2)} ر.س</span>
              </div>
              <Button className="btn-heritage w-full text-lg" onClick={() => navigate("/checkout")}>
                إتمام الطلب والدفع
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Cart;
