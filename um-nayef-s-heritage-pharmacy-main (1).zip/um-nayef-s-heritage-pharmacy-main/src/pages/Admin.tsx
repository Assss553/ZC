import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/Header";
import { SaduDivider } from "@/components/SaduDivider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getUser } from "@/lib/auth";
import { toast } from "sonner";
import { Pencil, Trash2, Plus, Search, Image as ImageIcon } from "lucide-react";

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image_url: string | null;
  stock: number;
}

interface Order {
  id: string;
  order_code: string;
  customer_name: string;
  customer_phone: string;
  customer_address: string;
  total: number;
  status: string;
  notes: string | null;
  receipt_url: string | null;
  created_at: string;
}

const STATUSES = ["قيد المراجعة", "تم التأكيد", "قيد التوصيل", "مكتمل", "ملغي"];

const Admin = () => {
  const user = getUser();
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [orderItems, setOrderItems] = useState<Record<string, any[]>>({});
  const [searchPhone, setSearchPhone] = useState("");

  // form
  const [editing, setEditing] = useState<Product | null>(null);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [stock, setStock] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imageUrl, setImageUrl] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user || !user.isAdmin) { navigate("/login"); return; }
    loadAll();
  }, []);

  const loadAll = async () => {
    const { data: ps } = await supabase.from("products").select("*").order("created_at", { ascending: false });
    setProducts(ps || []);
    await loadOrders();
  };

  const loadOrders = async (phoneFilter?: string) => {
    let q = supabase.from("orders").select("*").order("created_at", { ascending: false });
    if (phoneFilter) q = q.eq("customer_phone", phoneFilter);
    const { data: os } = await q;
    setOrders(os || []);
    if (os && os.length) {
      const { data: its } = await supabase.from("order_items").select("*").in("order_id", os.map(o => o.id));
      const grouped: Record<string, any[]> = {};
      (its || []).forEach((it: any) => { (grouped[it.order_id] ||= []).push(it); });
      setOrderItems(grouped);
    }
  };

  const resetForm = () => {
    setEditing(null); setName(""); setDescription(""); setPrice(""); setStock("");
    setImageFile(null); setImageUrl("");
  };

  const startEdit = (p: Product) => {
    setEditing(p); setName(p.name); setDescription(p.description || "");
    setPrice(String(p.price)); setStock(String(p.stock)); setImageUrl(p.image_url || "");
    setImageFile(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const saveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !price) { toast.error("الاسم والسعر مطلوبان"); return; }
    setSaving(true);
    try {
      let finalImage = imageUrl;
      if (imageFile) {
        const ext = imageFile.name.split(".").pop();
        const path = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
        const { error } = await supabase.storage.from("products").upload(path, imageFile);
        if (error) throw error;
        finalImage = supabase.storage.from("products").getPublicUrl(path).data.publicUrl;
      }
      const payload = {
        name: name.trim(), description: description.trim() || null,
        price: parseFloat(price), stock: parseInt(stock || "0"),
        image_url: finalImage || null,
      };
      if (editing) {
        await supabase.from("products").update(payload).eq("id", editing.id);
        toast.success("تم تحديث المنتج");
      } else {
        await supabase.from("products").insert(payload);
        toast.success("تم إضافة المنتج");
      }
      resetForm();
      loadAll();
    } catch (err: any) { toast.error("خطأ: " + err.message); }
    finally { setSaving(false); }
  };

  const deleteProduct = async (id: string) => {
    if (!confirm("هل أنت متأكدة من الحذف؟")) return;
    await supabase.from("products").delete().eq("id", id);
    toast.success("تم الحذف");
    loadAll();
  };

  const updateOrderStatus = async (id: string, status: string) => {
    await supabase.from("orders").update({ status }).eq("id", id);
    toast.success("تم تحديث الحالة");
    loadOrders(searchPhone || undefined);
  };

  return (
    <div className="min-h-screen">
      <Header />
      <div className="container mx-auto px-4 py-6">
        <h2 className="heritage-title text-4xl text-center mb-2">لوحة التحكم - أم نايف</h2>
        <SaduDivider />

        <Tabs defaultValue="products" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="products">المنتجات ({products.length})</TabsTrigger>
            <TabsTrigger value="orders">الطلبات ({orders.length})</TabsTrigger>
          </TabsList>

          {/* المنتجات */}
          <TabsContent value="products" className="space-y-6">
            <form onSubmit={saveProduct} className="card-3d sadu-frame p-6 space-y-3">
              <h3 className="font-black text-primary text-xl">
                {editing ? "✏️ تعديل منتج" : "➕ إضافة منتج جديد"}
              </h3>
              <div className="grid md:grid-cols-2 gap-3">
                <div>
                  <Label className="text-primary font-bold">اسم المنتج</Label>
                  <Input value={name} onChange={e => setName(e.target.value)} maxLength={100} required />
                </div>
                <div>
                  <Label className="text-primary font-bold">السعر (ر.س)</Label>
                  <Input type="number" step="0.01" min="0" value={price} onChange={e => setPrice(e.target.value)} required />
                </div>
                <div>
                  <Label className="text-primary font-bold">الكمية المتوفرة</Label>
                  <Input type="number" min="0" value={stock} onChange={e => setStock(e.target.value)} />
                </div>
                <div>
                  <Label className="text-primary font-bold flex items-center gap-1"><ImageIcon className="h-4 w-4"/> صورة المنتج (من المعرض)</Label>
                  <Input type="file" accept="image/*" onChange={e => setImageFile(e.target.files?.[0] || null)} />
                  {imageUrl && !imageFile && <img src={imageUrl} alt="" className="h-16 mt-1 rounded" />}
                </div>
              </div>
              <div>
                <Label className="text-primary font-bold">الوصف</Label>
                <Textarea value={description} onChange={e => setDescription(e.target.value)} rows={2} maxLength={500} />
              </div>
              <div className="flex gap-2">
                <Button type="submit" disabled={saving} className="btn-heritage flex-1">
                  {saving ? "..." : editing ? "حفظ التعديلات" : "إضافة المنتج"}
                </Button>
                {editing && <Button type="button" variant="outline" onClick={resetForm}>إلغاء</Button>}
              </div>
            </form>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {products.map(p => (
                <div key={p.id} className="card-3d p-3">
                  <div className="aspect-square rounded-lg bg-muted overflow-hidden mb-2">
                    {p.image_url ? <img src={p.image_url} alt={p.name} className="w-full h-full object-cover" /> :
                      <div className="w-full h-full flex items-center justify-center text-4xl">🫘</div>}
                  </div>
                  <h4 className="font-bold text-primary">{p.name}</h4>
                  <div className="flex justify-between text-sm mt-1">
                    <span>{Number(p.price).toFixed(2)} ر.س</span>
                    <span className="text-muted-foreground">المخزون: {p.stock}</span>
                  </div>
                  <div className="flex gap-1 mt-2">
                    <Button size="sm" variant="outline" className="flex-1" onClick={() => startEdit(p)}>
                      <Pencil className="h-3 w-3 ml-1" /> تعديل
                    </Button>
                    <Button size="sm" variant="destructive" onClick={() => deleteProduct(p.id)}>
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* الطلبات */}
          <TabsContent value="orders" className="space-y-4">
            <div className="card-3d p-4 flex gap-2">
              <Input value={searchPhone} onChange={e => setSearchPhone(e.target.value)}
                placeholder="ابحث برقم الجوال (05...)" dir="ltr" maxLength={10} />
              <Button onClick={() => loadOrders(searchPhone || undefined)} className="btn-heritage gap-1">
                <Search className="h-4 w-4" /> بحث
              </Button>
              <Button variant="outline" onClick={() => { setSearchPhone(""); loadOrders(); }}>الكل</Button>
            </div>

            {orders.length === 0 && <p className="text-center text-muted-foreground py-6">لا توجد طلبات</p>}

            {orders.map(o => (
              <div key={o.id} className="card-3d sadu-frame p-5">
                <div className="flex flex-wrap justify-between items-start gap-2 mb-3">
                  <div>
                    <p className="text-xs text-muted-foreground">كود الطلب</p>
                    <p className="font-black text-primary text-xl tracking-wider" dir="ltr">{o.order_code}</p>
                  </div>
                  <div>
                    <Label className="text-xs">حالة الطلب</Label>
                    <select value={o.status} onChange={e => updateOrderStatus(o.id, e.target.value)}
                      className="block border-2 border-primary rounded px-2 py-1 text-sm font-bold bg-card">
                      {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-2 text-sm">
                  <p><span className="text-muted-foreground">الاسم:</span> <strong>{o.customer_name}</strong></p>
                  <p><span className="text-muted-foreground">الجوال:</span> <a href={`tel:${o.customer_phone}`} className="font-bold underline" dir="ltr">{o.customer_phone}</a></p>
                  <p className="md:col-span-2"><span className="text-muted-foreground">📍 العنوان:</span> {o.customer_address}</p>
                  <p className="md:col-span-2"><span className="text-muted-foreground">التاريخ:</span> {new Date(o.created_at).toLocaleString("ar-SA")}</p>
                  {o.notes && <p className="md:col-span-2"><span className="text-muted-foreground">ملاحظات:</span> {o.notes}</p>}
                </div>
                <div className="border-t border-dashed mt-3 pt-2">
                  <p className="text-xs font-bold text-primary mb-1">المنتجات:</p>
                  {(orderItems[o.id] || []).map((it, idx) => (
                    <div key={idx} className="text-sm flex justify-between">
                      <span>{it.product_name} × {it.quantity}</span>
                      <span>{(Number(it.price) * it.quantity).toFixed(2)} ر.س</span>
                    </div>
                  ))}
                </div>
                <div className="border-t-2 border-primary mt-2 pt-2 flex justify-between items-center">
                  <span className="font-black text-primary">الإجمالي: {Number(o.total).toFixed(2)} ر.س</span>
                  {o.receipt_url && <a href={o.receipt_url} target="_blank" rel="noopener" className="text-sm underline text-primary">عرض الإيصال</a>}
                </div>
              </div>
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Admin;
