import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/Header";
import { SaduDivider } from "@/components/SaduDivider";
import { Button } from "@/components/ui/button";
import { addToCart } from "@/lib/cart";
import { toast } from "sonner";
import { ShoppingBag } from "lucide-react";

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image_url: string | null;
  stock: number;
}

const Index = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.from("products").select("*").order("created_at", { ascending: false })
      .then(({ data }) => { setProducts(data || []); setLoading(false); });
  }, []);

  const handleAdd = (p: Product) => {
    addToCart({ product_id: p.id, name: p.name, price: Number(p.price), image_url: p.image_url });
    toast.success(`أُضيف "${p.name}" إلى السلة`);
  };

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero */}
      <section className="relative overflow-hidden py-16 px-4">
        <div className="absolute inset-0 sadu-pattern" />
        <div className="container relative mx-auto text-center">
          <div className="mb-4 text-6xl">🌴 ☕ 🌴</div>
          <h1 className="heritage-title mb-4 text-5xl md:text-7xl">متجر أم نايف</h1>
          <p className="mb-2 text-xl md:text-2xl font-semibold text-primary">الدوى الشهابي الأصيل من حائل</p>
          <p className="mb-6 text-muted-foreground">نكهة الجدّات • جودة عريقة • توصيل لجميع المناطق</p>
          <SaduDivider />
          <div className="flex justify-center gap-3">
            <a href="#products"><Button className="btn-heritage">تسوّق الآن</Button></a>
            <Link to="/track"><Button className="btn-gold">تتبّع طلبك</Button></Link>
          </div>
        </div>
      </section>

      {/* المنتجات */}
      <section id="products" className="py-12 px-4">
        <div className="container mx-auto">
          <h2 className="heritage-title mb-2 text-center text-4xl">منتجاتنا</h2>
          <p className="text-center text-muted-foreground mb-8">من بيت أم نايف إلى بيتك</p>
          <SaduDivider />
          
          {loading ? (
            <div className="text-center py-12 text-primary">جاري التحميل...</div>
          ) : products.length === 0 ? (
            <div className="card-3d sadu-frame mx-auto max-w-lg p-8 text-center">
              <p className="text-lg text-primary font-semibold">لا توجد منتجات حالياً</p>
              <p className="text-muted-foreground mt-2">سيتم إضافة المنتجات قريباً من قبل أم نايف</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 perspective-3d">
              {products.map(p => (
                <article key={p.id} className="card-3d sadu-frame overflow-hidden">
                  <div className="aspect-square bg-muted overflow-hidden rounded-t-lg">
                    {p.image_url ? (
                      <img src={p.image_url} alt={p.name} className="h-full w-full object-cover" loading="lazy" />
                    ) : (
                      <div className="h-full flex items-center justify-center text-6xl">🫘</div>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="text-xl font-bold text-primary">{p.name}</h3>
                    {p.description && <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{p.description}</p>}
                    <div className="mt-3 flex items-center justify-between">
                      <span className="text-2xl font-black text-accent-foreground" style={{color: "hsl(var(--primary))"}}>
                        {Number(p.price).toFixed(2)} ر.س
                      </span>
                      <span className="text-xs text-muted-foreground">المتوفر: {p.stock}</span>
                    </div>
                    <Button onClick={() => handleAdd(p)} disabled={p.stock <= 0} className="btn-heritage w-full mt-3 gap-2">
                      <ShoppingBag className="h-4 w-4" />
                      {p.stock > 0 ? "أضف إلى السلة" : "نفد المخزون"}
                    </Button>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </section>

      <footer className="mt-16 py-8 text-center text-sm text-muted-foreground border-t-4 border-double border-primary">
        <div className="palm-divider">❖ ❖ ❖</div>
        <p>© متجر أم نايف - حائل • الأصالة في كل حبة</p>
      </footer>
    </div>
  );
};

export default Index;
