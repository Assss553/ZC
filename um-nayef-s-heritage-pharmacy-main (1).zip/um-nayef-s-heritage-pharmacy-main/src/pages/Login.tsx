import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Header } from "@/components/Header";
import { SaduDivider } from "@/components/SaduDivider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { loginUser } from "@/lib/auth";
import { toast } from "sonner";

const Login = () => {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      toast.error("الرجاء إدخال الاسم ورقم الهاتف");
      return;
    }
    if (!/^05\d{8}$/.test(phone.trim())) {
      toast.error("رقم الجوال يجب أن يبدأ بـ 05 ويتكون من 10 أرقام");
      return;
    }
    setLoading(true);
    try {
      const session = await loginUser(name, phone);
      toast.success(`أهلاً ${session.name} 🌹`);
      navigate(session.isAdmin ? "/admin" : "/");
      setTimeout(() => window.location.reload(), 100);
    } catch (err: any) {
      toast.error("حصل خطأ، حاول مرة أخرى");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen">
      <Header />
      <div className="container mx-auto px-4 py-12 flex justify-center">
        <div className="card-3d sadu-frame w-full max-w-md p-8">
          {/* سجادة تراثية */}
          <div className="mb-6 mx-auto w-32 h-32 relative" aria-hidden="true">
            <div className="absolute inset-0 rounded-full" style={{
              background: "var(--gradient-heritage)",
              boxShadow: "var(--shadow-carved)",
            }} />
            <div className="absolute inset-2 rounded-full sadu-pattern opacity-60" />
            <div className="absolute inset-0 flex items-center justify-center text-5xl">🪔</div>
          </div>

          <h2 className="heritage-title text-center text-3xl mb-2">تسجيل الدخول</h2>
          <p className="text-center text-muted-foreground mb-4">أهلاً بكم في بيت أم نايف</p>
          <SaduDivider />

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label htmlFor="name" className="text-primary font-bold">الاسم</Label>
              <Input id="name" value={name} onChange={e => setName(e.target.value)}
                placeholder="مثال: أم نايف" className="mt-1 text-right" maxLength={50} />
            </div>
            <div>
              <Label htmlFor="phone" className="text-primary font-bold">رقم الجوال</Label>
              <Input id="phone" value={phone} onChange={e => setPhone(e.target.value)}
                placeholder="05XXXXXXXX" type="tel" inputMode="numeric" className="mt-1 text-right ltr:text-left" maxLength={10} dir="ltr" />
            </div>
            <Button type="submit" disabled={loading} className="btn-heritage w-full">
              {loading ? "جاري الدخول..." : "دخول"}
            </Button>
          </form>

          <p className="text-xs text-muted-foreground text-center mt-4">
            بالدخول فأنت توافق على شروط متجر أم نايف التراثي
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
