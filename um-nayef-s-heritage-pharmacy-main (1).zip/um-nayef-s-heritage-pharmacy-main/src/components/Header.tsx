import { Link, useNavigate } from "react-router-dom";
import { ShoppingBag, User, LayoutDashboard, LogOut, Search } from "lucide-react";
import { getUser, logout } from "@/lib/auth";
import { Button } from "@/components/ui/button";

export const Header = () => {
  const user = getUser();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
    window.location.reload();
  };

  return (
    <header className="sticky top-0 z-50 backdrop-blur-md" style={{
      background: "linear-gradient(180deg, hsl(36 50% 96% / 0.95), hsl(36 50% 92% / 0.85))",
      boxShadow: "var(--shadow-soft)",
      borderBottom: "3px double hsl(var(--primary))",
    }}>
      <div className="container mx-auto flex items-center justify-between px-4 py-3">
        <Link to="/" className="flex items-center gap-2">
          <span className="text-3xl">🏺</span>
          <h1 className="heritage-title text-2xl md:text-3xl">متجر أم نايف</h1>
        </Link>
        <nav className="flex items-center gap-2">
          <Link to="/track">
            <Button variant="ghost" size="sm" className="gap-1">
              <Search className="h-4 w-4" /> تتبع طلب
            </Button>
          </Link>
          <Link to="/cart">
            <Button variant="ghost" size="icon"><ShoppingBag className="h-5 w-5" /></Button>
          </Link>
          {user ? (
            <>
              {user.isAdmin && (
                <Link to="/admin">
                  <Button size="sm" className="btn-gold gap-1">
                    <LayoutDashboard className="h-4 w-4" /> لوحة التحكم
                  </Button>
                </Link>
              )}
              <Button variant="ghost" size="icon" onClick={handleLogout} title="خروج">
                <LogOut className="h-5 w-5" />
              </Button>
            </>
          ) : (
            <Link to="/login">
              <Button size="sm" className="btn-heritage gap-1">
                <User className="h-4 w-4" /> دخول
              </Button>
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
};
