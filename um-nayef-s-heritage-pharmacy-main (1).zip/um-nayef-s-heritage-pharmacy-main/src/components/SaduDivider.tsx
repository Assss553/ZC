export const SaduDivider = () => (
  <div className="my-6 flex items-center justify-center gap-2" aria-hidden="true">
    <div className="h-3 flex-1 sadu-frame" style={{
      background: "repeating-linear-gradient(90deg, hsl(var(--primary)) 0 10px, hsl(var(--accent)) 10px 14px, hsl(var(--primary)) 14px 18px, transparent 18px 24px)"
    }} />
    <span className="text-2xl text-primary">❖</span>
    <div className="h-3 flex-1" style={{
      background: "repeating-linear-gradient(90deg, hsl(var(--primary)) 0 10px, hsl(var(--accent)) 10px 14px, hsl(var(--primary)) 14px 18px, transparent 18px 24px)"
    }} />
  </div>
);
