export interface CartItem {
  product_id: string;
  name: string;
  price: number;
  image_url: string | null;
  quantity: number;
}

const KEY = "umnaif_cart";

export function getCart(): CartItem[] {
  try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch { return []; }
}

export function setCart(items: CartItem[]) {
  localStorage.setItem(KEY, JSON.stringify(items));
}

export function addToCart(item: Omit<CartItem, "quantity">, qty = 1) {
  const cart = getCart();
  const existing = cart.find(i => i.product_id === item.product_id);
  if (existing) existing.quantity += qty;
  else cart.push({ ...item, quantity: qty });
  setCart(cart);
}

export function removeFromCart(product_id: string) {
  setCart(getCart().filter(i => i.product_id !== product_id));
}

export function updateQty(product_id: string, qty: number) {
  const cart = getCart();
  const item = cart.find(i => i.product_id === product_id);
  if (item) {
    if (qty <= 0) return removeFromCart(product_id);
    item.quantity = qty;
    setCart(cart);
  }
}

export function clearCart() { localStorage.removeItem(KEY); }

export function cartTotal(): number {
  return getCart().reduce((s, i) => s + i.price * i.quantity, 0);
}
