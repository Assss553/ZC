// نظام تسجيل دخول بسيط بالاسم والهاتف (محفوظ في localStorage + DB)
import { supabase } from "@/integrations/supabase/client";

export interface UserSession {
  name: string;
  phone: string;
  isAdmin: boolean;
}

const KEY = "umnaif_user";

export const ADMIN_PHONE = "0569529224";
export const ADMIN_NAME = "أم نايف";

export function getUser(): UserSession | null {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

export function setUser(u: UserSession) {
  localStorage.setItem(KEY, JSON.stringify(u));
}

export function logout() {
  localStorage.removeItem(KEY);
}

export async function loginUser(name: string, phone: string): Promise<UserSession> {
  const cleanPhone = phone.trim();
  const cleanName = name.trim();
  
  // تحقق من المسؤول
  const { data: roleData } = await supabase
    .from("user_roles")
    .select("role")
    .eq("phone", cleanPhone)
    .eq("role", "admin")
    .maybeSingle();
  
  const isAdmin = !!roleData;

  // أنشئ أو حدّث الملف
  const { data: existing } = await supabase
    .from("profiles")
    .select("*")
    .eq("phone", cleanPhone)
    .maybeSingle();

  if (!existing) {
    await supabase.from("profiles").insert({ name: cleanName, phone: cleanPhone });
  }

  const session: UserSession = { name: cleanName, phone: cleanPhone, isAdmin };
  setUser(session);
  return session;
}

export function generateOrderCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "UN-";
  for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}
