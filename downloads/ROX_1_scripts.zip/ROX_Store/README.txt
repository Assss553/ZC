ROX Store - full pack v2 | All rights reserved.

INSTALL
1. Copy [rox], [ox] and [standalone] into resources/.
   [ox]/ox_inventory REPLACES your ox_inventory (official GPL-3.0 build + ROX theme). Back up your data/items.lua first
   and copy your own items into the new data/items.lua.
2. Copy rox.cfg next to server.cfg and add "exec rox.cfg" after oxmysql, ox_lib, qbx_core, ox_target, pma-voice.
3. Maps / weapons need a CodeWalker conversion (Windows):
   - rox_maps/codewalker_xml   -> Tools > Import XML -> put the .ydr/.ytyp/.ymap in rox_maps/stream/
   - rox_weapons/codewalker_xml -> same -> put the .ydr in rox_weapons/stream/
4. Item images: item_images/ -> ox_inventory/web/images/
5. Inventory: F2 opens the style chosen in /settings > MENU (3D or wheel). Press C inside to switch.
6. Read the "KEY CONFLICTS" part at the bottom of rox.cfg.

NOT TESTED IN GAME YET - report anything that does not work and it will be fixed.
Licences: ox_inventory + zerodream_3dmap = GPL-3.0 (kept as separate resources, keep their LICENSE files).
Weapon models in rox_weapons = CC0 (see rox_weapons/CREDITS.md).
