ROX Store - full pack
=====================
Requirements: qbx_core, ox_lib, oxmysql, ox_target (+ pma-voice optional for HUD voice).

INSTALL
1. Copy "[rox]" into your resources folder.
2. Copy "rox.cfg" next to server.cfg and add "exec rox.cfg" after your core resources.
3. Database: all tables are created automatically on first start.
   (rox_realestate/sql/install.sql is there if you prefer to import it manually.)
4. Set yourself as owner of the admin panel (see rox.cfg) and restart the server.

ONE EDIT IN ox_lib (so EVERY notification uses the ROX design)
File: ox_lib/resource/interface/client/notify.lua
At the first line inside  function lib.notify(data)  add:
    if GetResourceState('rox_notify') == 'started' then return exports.rox_notify:Notify(data) end

ATM: disable the ATM target of your old banking script so only the ROX ATM shows.

COMMANDS / KEYS
/admin or F10   admin console        /ipad   real estate iPad
F1              radial menu          /hud    HUD settings
/cash  /bank    show money           ESC     pause menu
/minimap        toggle map           /testnotify  test notifications

Each resource has its own README.md with all settings (config.lua).
